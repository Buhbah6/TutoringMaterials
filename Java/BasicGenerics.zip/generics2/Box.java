package generics2;

import java.util.ArrayList;

/**
 * @author Anthony Nadeau
 */
public class Box <Item>{
    private ArrayList<Item> items;

    public Box() {
        items = new ArrayList();
    }
    
    public Box(ArrayList items) {
        this.items = items;
    }
    
    public boolean add(Item i) {
        return items.add(i);
    }
    
    public boolean remove(Item i) {
        return items.remove(i);
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }
    
    
    
    
}
