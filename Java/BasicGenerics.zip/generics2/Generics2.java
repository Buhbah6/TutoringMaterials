package generics2;

import java.util.ArrayList;

/**
 * @author Anthony Nadeau
 */
public class Generics2 {
    
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        Box<Integer> intBox = new Box();
        Box<String> stringBox = new Box();
    }
    
}
