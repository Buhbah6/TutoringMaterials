package textioquestion;

import java.io.*;
import java.util.*;

/**
 * @author Anthony Nadeau
 */
public class Driver2 {
     
    public static void main(String[] args) throws IOException {
        
        // Basic hardcoded data
        String path = "src\\NodeFile\\Nodes.txt";
        char initialChar = '.';
        int initialInt = 0;
    
        // File IO objects
        File file = new File(path);
        PrintWriter input = new PrintWriter(new FileOutputStream(file, true));
        Scanner output = new Scanner(file);
        
        // ArrayLists to store Data
        ArrayList<Integer> intList = new ArrayList();
        ArrayList<Character> charList = new ArrayList();
        
        // Establishing current file contents
        while (output.hasNext()) {
            String data = output.nextLine();
            if (!output.hasNext()) {
                initialChar = data.charAt(0);
                initialInt = Integer.parseInt(data.substring(1));
            }
        }
        
        // Writing to the file
        for (int i = 1; i <= 5; i++) {
            input.write(("\n" + ((char)(initialChar + i))) + (initialInt + i));
        }
        input.close();
        
        // Reading from the file and storing the data
        output = new Scanner(file);
        while (output.hasNext()) {
            String currentLine = output.nextLine();
            charList.add(currentLine.charAt(0));
            intList.add(Integer.parseInt(currentLine.substring(1)));
        }
        
        // Outputting data inside the Arraylists using foreach
        System.out.println("Integer ArrayList contents:");
        for (Integer it : intList) {
            System.out.print(it + " ");
        }
        
        System.out.println("\n");
        
        System.out.println("Character ArrayList contents:");
        for (Character ch : charList) {
            System.out.print(ch + " ");
        }
    }
}
