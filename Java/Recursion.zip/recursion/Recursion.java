package recursion;

import java.util.Scanner;

/**
 * @author Anthony Nadeau
 */
public class Recursion {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a number that you would like to see all numbers prior to it.");
        int num = input.nextInt();
        printDecreasingValue(num);
    }
    
    public static void printDecreasingValue(int initialNum) {
        System.out.print(initialNum + " ");
        if (initialNum != 0)
            printDecreasingValue(--initialNum);
    }
}
