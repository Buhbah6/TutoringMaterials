package recursion;

/**
 * @author Anthony Nadeau
 */
public class Recursion2 {

    public static void main(String[] args) { // 5^5
        System.out.println("Math.pow = " + Math.pow(5, 5));
        System.out.print("Our pow = ");
        pow(5, 5);
    }
    
    public static void pow(int number, int power) {
        System.out.println(pow(number, --power, number));
    }
    
    // Write a method that will calculate the first number passed to the power of the second number passed recursively
    public static int pow(int number, int power, int result) {
        if (power > 0) {
            power--;
            return pow(number, power, number * result);
        }
        return result;
    }
}
