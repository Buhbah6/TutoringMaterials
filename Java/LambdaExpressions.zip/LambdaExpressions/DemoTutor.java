package lambda;

interface PrintWords {
    public void print(String words);
}

public class DemoTutor {
    
    public static void main(String[] args) {
        // --------------------------ORIGINAL----------------------------
        PrintWords p1 = new PrintWords() {
            
            @Override
            public void print(String words) {
                System.out.println(words);
            }
        };
        
        // Calling the method
        p1.print("These are words");
        
        // --------------------------LAMBDA-----------------------------
        // Lambda
        PrintWords p2 = (String words) -> System.out.println(words);
        
        // Calling the method
        p2.print("These are words");
    }
}
