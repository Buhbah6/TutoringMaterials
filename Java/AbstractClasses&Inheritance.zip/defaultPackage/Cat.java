package defaultPackage;

/**
 * @author Anthony Nadeau
 */
public class Cat extends Animal {

    private int legs;
// Implement all abstract methods

    public Cat() {}
    
    public Cat(int age, int height, int legs) {
        super(age, height);
        this.legs = legs;
    }
    
    @Override
    public String speak() {
        return "Meow";
    }

    @Override
    public int get_legs() {
        return legs;
    } 
}
