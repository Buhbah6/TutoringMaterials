package defaultPackage;

/**
 * @author Anthony Nadeau
 */
public class Driver {
    public static void main(String[] args) {
       // Animal animal = new Animal();
       Animal dog = new Dog();
       Animal cat = new Cat();
       Dog dog2 = new Dog();
       Cat cat2 = new Cat();   
    }
   
}
