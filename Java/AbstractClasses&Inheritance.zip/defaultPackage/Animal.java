package defaultPackage;

public abstract class Animal {
    private int age;
    private int height;

    public Animal() {}
    
    public Animal(int age, int height) {
        this.age = age;
        this.height = height;
    }
    
    public abstract String speak();
    public abstract int get_legs();

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    } 
}
