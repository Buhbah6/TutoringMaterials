package defaultPackage;

/**
 * @author Anthony Nadeau
 */
public class Dog extends Animal {
// Implement all abstract methods
    private int legs;
    
    public Dog() {}
    
    public Dog(int age, int height, int legs) {
        super(age, height);
        this.legs = legs;
    }
    
    @Override
    public String speak() {
        return "Bark";
    }

    @Override
    public int get_legs() {
        return legs;
    }
    
}
