package classdesign;

/**
 * @author Anthony Nadeau
 */
public class CarClass {
    
    // Instance Variables -> Attributes
    private String name;
    private double price;
    private double gasCapacity;
    
    // Default Constructor -> No-arg constructor
    public CarClass() {
        name = null;
        price = 0;
        gasCapacity = 0;
    }
    
    // Parameterized Constructor -> contains all attributes
    public CarClass(String name, double price, double gasCapacity) {
        this.name = name;
        this.price = price;
        this.gasCapacity = gasCapacity;
    }
    
    // Copy Constructor // DEEP COPY
    public CarClass(CarClass c) {
        this.name = c.getName();
        this.price = c.getPrice();
        this.gasCapacity = c.getGasCapacity();
    }
    
    // Other helpful methods that should be considered when designing a class
    
    @Override
    public String toString() {
        return String.format("Name: %s\nPrice: %.2f\n", name, price);
    }
    
    // Compares this object to another Object (passed as a parameter)
    @Override
    public boolean equals(Object obj) {
        return this == obj; // If the objects have the same memory address, returns true
    }

    // GETTERS AND SETTERS //
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getGasCapacity() {
        return gasCapacity;
    }

    public void setGasCapacity(double gasCapacity) {
        this.gasCapacity = gasCapacity;
    } 
}
