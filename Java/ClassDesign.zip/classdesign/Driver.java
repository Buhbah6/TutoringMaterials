package classdesign;

/**
 * @author Anthony Nadeau
 */
public class Driver {
    public static void main(String[] args) {
        CarClass c1 = new CarClass("Toyota", 100, 5);
        CarClass c2 = new CarClass("Mazda", 110, 10);
        CarClass c3 = new CarClass(c1);
        
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        
        System.out.println(c1.equals(c2));
        System.out.println(c1.equals(c3));
        System.out.println(c2.equals(c3));
        System.out.println(c1.equals(c1));
    }
}
