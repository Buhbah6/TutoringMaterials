package Q1Hospital;

public class Patient implements Comparable<Patient>{
    private String name;
    private int age;
    private int priority;
    
    public Patient() {
        name = "Unnamed";
        age = 0;
        priority = 0;
    }
    
    public Patient(String name, int age, int priority) {
        this.name = name;
        this.age = age;
        this.priority = priority;
    }

    @Override
    public int compareTo(Patient pat) {
       if (priority > pat.getPriority())
           return -1;
       else if (priority < pat.getPriority())
           return 1;
       return 0;
    }

    @Override
    public String toString() {
        return name + " - " + priority;
    }

    // GETTERS AND SETTERS
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
