package Q1Hospital;

import java.util.*;

public class Driver {
    public static void main(String[] args) {
        // Creating the data structures
        Queue<Patient> q1 = new LinkedList();
        PriorityQueue<Patient> q2 = new PriorityQueue();
        
        // Storing the values in arrays (for efficiency)
        String[] names = {"Anthony", "Shahe", "Giuliana", "Joe", "Gerald"};
        int[] ages = {19, 19, 20, 30, 77};
        int[] priority = {6, 4, 9, 4, 10};
        
        // Populating the queue and the priority queue
        for (int i = 0; i < names.length; i++) {
            Patient p = new Patient(names[i], ages[i], priority[i]);
            q1.add(p);
            q2.add(p);
        }
        
        // Outputting the queue contents
        System.out.println("Queue Iterator:");
        iteratorPrints(q1);
        
        System.out.println("PriorityQueue Iterator:");
        iteratorPrints(q2);
        
        System.out.println("Queue ForEach:");
        forEach(q1);
        
        System.out.println("PriorityQueue ForEach:");
        forEach(q2);
    }
    
    // Methods to facilitate printing with forEach and Iterator
    public static void forEach(Iterable it) {
        for (Object p : it) 
            System.out.print(p + " | ");
        System.out.println("\n");
    }
    
    public static void iteratorPrints(Iterable it) {
        Iterator it1 = it.iterator();
        while (it1.hasNext())
            System.out.print(it1.next() + " | ");
        System.out.println("\n");
    }
}
