package Q2School;

public class StudentException extends Exception {
    private String message;
    
    public StudentException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
