package Q2School;

import java.util.*;

public class SchoolSystem {
    public static void main(String[] args) {
        // Create Scanner for user input
        Scanner input = new Scanner(System.in);
        
        // Creating the ArrayList of classes
        ArrayList<HashMap<String, Double>> classes = new ArrayList();
        
        // 2D array of all student names
        String[][] studentNames = {
            {"Anthony", "Shahe", "Giuliana", "Joe", "Gerald"},
            {"Jonathan", "Leonard", "George", "Kosta", "Hugh"},
            {"Armen", "Gevorg", "Lisa", "Jeremy", "Sarah"}
        };

        // 2D array of all student grades
        double[][] studentGrades = {
            {90.0, 85.5, 99.9, 67.2, 4.0},
            {70.3, 85.5, 84.9, 11.2, 93.0},
            {45.0, 82.6, 97.8, 100.0, 0.0}
        };

        // for loop to loop through the first dimension array
        for (int i = 0; i < studentGrades.length; i++) {
            // Hashmap to store the students of the class
            HashMap<String, Double> students = new HashMap();
            // for loop to create the students of the second dimension arrays and store them in the map
            for (int j = 0; j < studentGrades[i].length; j++)
                students.put(studentNames[i][j], studentGrades[i][j]);
            // Add the class hashmap to the arrayList
            classes.add(students);
        }

        boolean active = true;
        boolean inClass = true;
        HashMap<String, Double> primary;
        System.out.println("Welcome to the Student Management System!");
        while (active) {
            System.out.println("Below, Please input the number of the class you would like to access (1, 2, or 3):");
            try {
                int classNum = input.nextInt();
                if (classNum > 3 || classNum < 1)
                    throw new Exception();
                primary = classes.get(classNum - 1);
                inClass = true;
                while (inClass) {
                    try {
                        System.out.println("\nStudents in the class:");
                        for (String studentName : primary.keySet()) {
                            System.out.println(studentName);
                        }
                        System.out.println("\nPlease enter the name of the student of which you would like to view their grade");
                        String name = input.next();
                        if (!primary.containsKey(name))
                            throw new StudentException("The name you entered is invalid, please try again");
                        System.out.println(name + " has a grade of " + primary.get(name));
                        System.out.println("\nSelect 1 to view another student in this class");
                        System.out.println("Select 2 to view students from another class");
                        System.out.println("Select 3 to exit the system");
                        int choice = input.nextInt();
                        switch (choice) {
                            case 1:
                                continue;
                            case 2:
                                inClass = false;
                                break;
                            case 3:
                                inClass = false;
                                active = false;
                                System.out.println("Thank you for using the Student Management System today!");
                                break;
                            default:
                                System.out.println("Invalid value. Showing students for this class again");
                        }
                    }
                    catch (StudentException se) {
                        System.out.println(se.getMessage());
                    }
                }
            }
            catch(Exception e) {
                System.out.println("Invalid value. Please try again.");
            }
        } 
    }
}
