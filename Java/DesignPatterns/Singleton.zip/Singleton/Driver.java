package singletonDesign;

public class Driver {

    public static void main(String[] args) {
        Dog d1 = Dog.getInstance("Sparky");
        Dog d2 = Dog.getInstance("LemonDrop");
        Dog d3 = Dog.getInstance("Senku");
        
        System.out.println(d1); 
        System.out.println(d2); 
        System.out.println(d3); 
    }
    
}
