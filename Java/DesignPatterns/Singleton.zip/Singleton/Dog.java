package singletonDesign;

public class Dog {
    private String name;
    private static Dog dog; // static variable of the class we want only one of
    
    public static Dog getInstance(String name) {
        if (dog == null)
            dog = new Dog(name);
        return dog;
    }
    
    private Dog(String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return "This dog is named: " + name;
    }
}
