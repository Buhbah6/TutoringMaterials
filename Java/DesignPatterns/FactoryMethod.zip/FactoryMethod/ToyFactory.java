package factoryTutor;

public abstract class ToyFactory {
    
    public static Toy createToy(int choice, int ID, int size) {
        switch (choice) {
            case 0:
                return new ToyCar(ID, "Vroom");
            case 1:
                return new ToyRobot(ID, "Rawr", size);
            default:
                return null;
        }
    }
}
