package factoryTutor;

public class ToyRobot extends Toy{
    private int size;
    
    public ToyRobot(int ID, String sound, int size) {
        this.setID(ID);
        this.setSound(sound);
        this.size = size;
    }

    @Override
    public void playSound() {
        System.out.println(this.getSound());
    }
    
    public void beep() {
        System.out.println("Beep");
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
    @Override
    public String toString() {
        return "This is a Toy Robot";
    }
    
}
