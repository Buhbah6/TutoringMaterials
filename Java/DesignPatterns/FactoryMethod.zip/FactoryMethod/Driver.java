package factoryTutor;

import java.util.Scanner;

public class Driver {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Welcome to the Online Toy Store.");
        System.out.println("Enter 0 to purchase a Toy Car, or 1 to purchase a Toy Robot");
        int choice = input.nextInt();
        // The following line takes the choice and creates the selected toy using the ToyFactory
        Toy selectedToy = ToyFactory.createToy(choice, 1, 10); 
        System.out.println(selectedToy);
    }
    
}
