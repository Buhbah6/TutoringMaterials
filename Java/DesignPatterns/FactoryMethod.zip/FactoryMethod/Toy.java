package factoryTutor;

public abstract class Toy {
    private int ID;
    private String sound;
    
    public abstract void playSound();

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getSound() {
        return sound;
    }

    public void setSound(String sound) {
        this.sound = sound;
    }
    
    
}
