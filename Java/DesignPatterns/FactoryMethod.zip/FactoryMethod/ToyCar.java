package factoryTutor;

public class ToyCar extends Toy{
    
    public ToyCar(int ID, String sound) {
        this.setID(ID);
        this.setSound(sound);
    }

    @Override
    public void playSound() {
        System.out.println(this.getSound());
    }
    
    @Override
    public String toString() {
        return "This is a Toy Car";
    }
    
}
