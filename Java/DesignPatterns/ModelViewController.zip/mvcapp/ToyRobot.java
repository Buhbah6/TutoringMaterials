package mvcapp;

/**
 * This class is the Model in the MVC architecture
 * It should contain the functional logic of the Robot
 */
public class ToyRobot {
    private String name;
    
    public ToyRobot() {
        name = "Robot";
    }
    
    public ToyRobot(String name) {
        this.name = name;
    }
    
    public void move() {
        System.out.println("Moved");
    }

    @Override
    public String toString() {
        return "ToyRobot{" + "name=" + name + '}';
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }    
}
