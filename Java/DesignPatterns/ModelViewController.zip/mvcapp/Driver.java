package mvcapp;

/**
 * Driver class for the ToyRobot MVC
 */
public class Driver {
    public static void main(String[] args) {
        ToyController tc = new ToyController();
        
        tc.move();
        tc.move();
        tc.move();
    }
}
