package mvcapp;

/**
 * This class is the View in the MVC architecture
 * It should contain what the user will see
 */
public class ToyView {
    private ToyRobot tr;
    
    public ToyView(ToyRobot tr) {
        this.tr = tr;
    }
    
    public void view(int moves) {
        System.out.println(tr);
        System.out.println("The Robot has moved " + moves + " times");
    }
}
