package mvcapp;

/**
 * This class is the Controller in the MVC architecture
 * It should be how the user interacts with the Robot
 */
public class ToyController {
    private ToyRobot tr;
    private ToyView tv;
    private int moves;
    
    public ToyController() {
        tr = new ToyRobot();
        tv = new ToyView(tr);
        moves = 0;
    }
    
    public ToyController(ToyRobot tr) {
        this.tr = tr;
        tv = new ToyView(this.tr);
        moves = 0;
    }
    
    public void move() {
        tr.move();
        moves++;
        updateView();
    }
    
    public void updateView() {
        tv.view(moves);
    }
}
